import React from "react";
import './css/Sidebar.css';
import { NavLink } from "react-router-dom";

const Sidebar = () =>{

    const ShowMenu = () =>{
        if(document.getElementById('submenu').style.display === 'block'){
            document.getElementById('submenu').style.display = 'none';
            document.getElementById('drop').className = 'fas fa-angle-right';
        }else{
            document.getElementById('submenu').style.display = 'block';
            document.getElementById('drop').className = 'fas fa-angle-down';
            document.getElementById('submenu1').style.display = 'none';
            document.getElementById('drop1').className = 'fas fa-angle-right';
        }
    }

    const ShowMenu1 = () =>{
        if(document.getElementById('submenu1').style.display === 'block'){
            document.getElementById('submenu1').style.display = 'none';
            document.getElementById('drop1').className = 'fas fa-angle-right';
        }else{
            document.getElementById('submenu1').style.display = 'block';
            document.getElementById('drop1').className = 'fas fa-angle-down';
            document.getElementById('submenu').style.display = 'none';
            document.getElementById('drop').className = 'fas fa-angle-right';
        }
    }

    return(
        <>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12 m-0 p-0">
                        <div className="sidebar">
                            <div className="sidebar-top">
                                <h4 className="text-center pt-3">CMS</h4><hr></hr>
                            </div>
                            <div id="sidebar-bottom">
                                <NavLink to={'/'} className={'nav mt-3'} id="active"><i class="fas fa-tachometer-alt"></i> Dashboard</NavLink>
                                <NavLink to={'/'} className={'nav'}><i class="fas fa-home"></i> Home</NavLink>
                                <NavLink to={''} className={'nav'} onClick={ShowMenu}><i class="fas fa-user"></i> Student <i id="drop" className="fas fa-angle-right"></i></NavLink>
                                
                                <div id="submenu">
                                    <NavLink to={'/pages/AddStudent'} className={'subnav'}><i class="far fa-circle"></i> Add Student</NavLink>
                                    <NavLink to={''} className={'subnav'}><i class="far fa-circle"></i> View Student</NavLink>
                                </div>

                                <NavLink to={''} className={'nav'} onClick={ShowMenu1}><i class="fas fa-user"></i> Teacher <i id="drop1" className="fas fa-angle-right"></i></NavLink>
                                
                                <div id="submenu1">
                                    <NavLink to={''} className={'subnav'}><i class="far fa-circle"></i> Add Teacher</NavLink>
                                    <NavLink to={''} className={'subnav'}><i class="far fa-circle"></i> View Teacher</NavLink>
                                </div>

                                <NavLink to={''} className={'nav'}><i class="fas fa-user"></i> Staff <i id="drop2" className="fas fa-angle-right"></i></NavLink>
                                <NavLink to={''} className={'nav'}><i class="fas fa-bus"></i> Transport <i id="drop3" className="fas fa-angle-right"></i></NavLink>
                                <NavLink to={''} className={'nav'}><i class="fas fa-book"></i> Admission <i id="drop4" className="fas fa-angle-right"></i></NavLink>
                                <NavLink to={''} className={'nav'}><i class="fas fa-table"></i> Attendance <i id="drop5" className="fas fa-angle-right"></i></NavLink>
                                <NavLink to={''} className={'nav'}><i class="fas fa-graduation-cap"></i> School <i id="drop6" className="fas fa-angle-right"></i></NavLink>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Sidebar