import React, { useState, useRef } from "react";
import './css/student.css';
import { NavLink } from "react-router-dom";

const AddStudentForm = () =>{

    const [student, setStudent] = useState({
        name:'',
        fname:'',
        mobile:'',
        mail:'',
        adhar:'',
        dob:'',
        gender:'',
        rel:'',
        image:''
    })
    const [number, setNumber] = useState('');

    const onValueChange = (e) =>{
        setStudent({...student, [e.target.name] : e.target.value});
        console.log(student)
    }

    const onValueChangeNew = (e) =>{
        setStudent({...student, [e.target.name] : e.target.value})
        let inputValue = e.target.value;

        inputValue = inputValue.replace(/\s/g, '');
        inputValue = inputValue.slice(0, 12);

        inputValue = inputValue.replace(/(\d{4})/g, '$1 ');
        setNumber(inputValue);
    }

    const fileDate = (e) =>{
        setStudent({...student, image : e.target.files[0]});
    }
    
    const nameRef = useRef(null);
    const refFather = useRef(null);

    const submitData = (e) =>{
        e.preventDefault();

        const {name, fname, mobile, mail, adhar, dob, gender, rel, image} = student;
        if(!name){
            document.getElementById('nameValid').style.display = 'block';
            nameRef.current.focus();
        }else if(!fname){
            alert("Enter Your Father's Name");
            refFather.current.focus();
        }else if(!mobile){
            alert("Enter Your Mobile");
        }else if(mobile.length !== 10 ){
            alert("Enter Your 10 Digit Mobile Number");
        }else if(!mail){
            alert("Enter Your Email Id");
        }else if(!adhar){
            alert("Enter Your Aadhar Number");
        }else if(adhar.length !== 14){
            alert("Enter 12 Digit Adhar Number");
        }else if(!dob){
            alert("Enter Date Of Birth")
        }else if(!gender){
            alert("Select Your Gender")
        }else if(!rel){
            alert("Select Your Religion")
        }else if(!image){
            alert("Upload Your Image");
        }

    }

    return(
        <>
            <div className="container-fluid mt-4">
                <div className="row">
                    <div className="col-12">
                        <div className="body-title">
                            <span><i class="fas fa-tachometer-alt"></i> Dashboard</span> <span className="float-right"><NavLink to={'/'}><span className="pr-1">Home</span></NavLink> <i className="fas fa-angle-right" style={{fontSize:'14px'}}></i><i className="fas fa-angle-right" style={{fontSize:'14px'}}></i> <span className="pl-1 pr-1">Student</span> <i className="fas fa-angle-right" style={{fontSize:'14px'}}></i><i className="fas fa-angle-right" style={{fontSize:'14px'}}></i> <span className="pl-1">Add Student</span></span><hr></hr>
                        </div>
                    </div>
                </div>

                <form>
                    <div className="row">
                        <div className="col-12">
                            <div className="student-form pl-4 pr-4">
                                <div className="student-form-top">
                                    <h5>Student Registration Form</h5>
                                </div>
                                <div className="row mt-3">
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Name <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="text" name="name" ref={nameRef} onChange={(e) => onValueChange(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Name" />
                                                <p id="nameValid"><i>Please Enter Your Name *</i></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Father's Name <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="text" name="fname" ref={refFather} onChange={(e) => onValueChange(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Father's Name" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Mobile Number <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="text" name="mobile" onChange={(e) => onValueChange(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Mobile Number" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row mt-2">
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email Id <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="email" name="mail" onChange={(e) => onValueChange(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Name" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Aadhar Number <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="text" name="adhar" value={number} onChange={(e) => onValueChangeNew(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Father's Name" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Date Of Birth <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="date" name="dob" onChange={(e) => onValueChange(e)} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Mobile Number" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="row mt-2">
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect1">Gender <span style={{color:'red'}}><small>*</small></span></label>
                                                <select name="gender" onChange={(e) => onValueChange(e)} class="form-control" id="exampleFormControlSelect1">
                                                    <option disabled selected value={''}>--Select Gender--</option>
                                                    <option value={'male'}>Male</option>
                                                    <option value={'female'}>Female</option>
                                                    <option value={'other'}>Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleFormControlSelect1">Religion <span style={{color:'red'}}><small>*</small></span></label>
                                                <select name="rel" onChange={(e) => onValueChange(e)} class="form-control" id="exampleFormControlSelect1">
                                                    <option disabled selected value={''}>--Select Religion--</option>
                                                    <option value={'hindu'}>Hindu</option>
                                                    <option value={'islam'}>Islam</option>
                                                    <option value={'sikh'}>Sikh</option>
                                                    <option value={'other'}>Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-12 col-md-4">
                                        <div className="name">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Image <span style={{color:'red'}}><small>*</small></span></label>
                                                <input type="file" name="image" onChange={fileDate} class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Mobile Number" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row mt-2">
                                    <div className="col-12 m-0 p-0">
                                        <div className="btn">
                                            <button className="btn btn-primary" onClick={submitData}>Submit</button>
                                            <input type="reset" value={'Reset'} className="btn btn-danger mr-3"></input>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </>
    )
}

export default AddStudentForm