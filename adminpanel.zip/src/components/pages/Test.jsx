import React, { useState } from 'react';

const NumberInputWithSpace = () => {
  const [number, setNumber] = useState('');

  const handleInputChange = (e) => {
    let inputValue = e.target.value;

    // Remove any existing spaces
    inputValue = inputValue.replace(/\s/g, '');

    // Add a space after every 4 digits
    inputValue = inputValue.replace(/(\d{4})/g, '$1 ');

    setNumber(inputValue);
  };

  return (
    <input
      type="text"
      value={number}
      onChange={handleInputChange}
      placeholder="Enter a number"
    />
  );
};

export default NumberInputWithSpace;
